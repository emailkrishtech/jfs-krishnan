import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TmptableComponent } from './tmptable.component';

describe('TmptableComponent', () => {
  let component: TmptableComponent;
  let fixture: ComponentFixture<TmptableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TmptableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TmptableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
