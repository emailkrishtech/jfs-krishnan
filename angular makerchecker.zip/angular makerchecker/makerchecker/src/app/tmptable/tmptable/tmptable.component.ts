import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tmptable',
  templateUrl: './tmptable.component.html',
  styleUrls: ['./tmptable.component.css']
})
export class TmptableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
