export class TmpTable{
    customerId: number;
    customerName: string;
    emailAddress: string;
    status: string;
    createDate: string;
    createdBy: string;
}