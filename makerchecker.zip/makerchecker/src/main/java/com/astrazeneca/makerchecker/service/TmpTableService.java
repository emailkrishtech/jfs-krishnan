/**
 * 
 */
package com.astrazeneca.makerchecker.service;

import java.util.List;

import com.astrazeneca.makerchecker.entity.TmpTable;;

/**
 * @author : Krishnan.N
 * @date : Mar 14, 2019
 */
public interface TmpTableService {
	TmpTable create(TmpTable tmpTable);

	TmpTable delete(int id);

    List<TmpTable> findAll();

    TmpTable findById(int id);

    TmpTable update(TmpTable tmpTable);

}
