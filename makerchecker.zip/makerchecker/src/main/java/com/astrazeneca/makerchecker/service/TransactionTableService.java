/**
 * 
 */
package com.astrazeneca.makerchecker.service;

import java.util.List;

import com.astrazeneca.makerchecker.entity.TransactionTable;

/**
 * @author : Krishnan.N
 * @date : Mar 15, 2019
 */
public interface TransactionTableService {
	TransactionTable create(TransactionTable transactionTable);

	TransactionTable delete(int id);

    List<TransactionTable> findAll();

    TransactionTable findById(int id);

    TransactionTable update(TransactionTable transactionTable);
}
