/**
 * 
 */
package com.astrazeneca.makerchecker.repository;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.astrazeneca.makerchecker.entity.TmpTable;

/**
 * @author : Krishnan.N
 * @date : Mar 14, 2019
 */
public interface TmpTableRepository extends Repository<TmpTable, Integer> {

    void delete(TmpTable tmpTable);

    List<TmpTable> findAll();

    TmpTable findOne(int id);

    TmpTable save(TmpTable tmpTable);


}
