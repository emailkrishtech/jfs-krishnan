/**
 * 
 */
package com.astrazeneca.makerchecker.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author : Krishnan.N
 * @date : Mar 14, 2019
 */
@Entity
@Table(name="tmp_table")
public class TmpTable {
	
	@Id
	@Column(nullable = false)
	private int customerId;
	@Column(nullable = false)
	private String customerName;
	@Column(nullable = false)
	private String emailAddress;
	@Column(nullable = false)
	private String status;
	@Column
	private String createDate;
	@Column
	private String createdBy;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	
	
}
