/**
 * 
 */
package com.astrazeneca.makerchecker.service;

import java.util.List;

import com.astrazeneca.makerchecker.entity.User;

/**
 * @author : Krishnan.N
 * @date : Mar 14, 2019
 */
public interface UserService {
	User create(User user);

    User delete(int id);

    List<User> findAll();

    User findById(int id);

    User update(User user);
    	 
}
