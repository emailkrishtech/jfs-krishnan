/**
 * 
 */
package com.astrazeneca.makerchecker.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.astrazeneca.makerchecker.entity.TmpTable;
import com.astrazeneca.makerchecker.service.TmpTableService;
/**
 * @author : Krishnan.N
 * @date : Mar 15, 2019
 */
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/maker")
public class TmpTableController {
	@Autowired
	private TmpTableService tmpTableService;
	
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public TmpTable create(@RequestBody TmpTable tmpTable){
         return tmpTableService.create(tmpTable);
    }

    @GetMapping(path = {"/{id}"})
    public TmpTable findOne(@PathVariable("id") int id){
        return tmpTableService.findById(id);
    }

    @PutMapping(path = {"/{id}"})
    public TmpTable update(@PathVariable("id") int id, @RequestBody TmpTable tmpTable){
        
        tmpTable.setCustomerId(id);
        return tmpTableService.update(tmpTable);
    }

    @DeleteMapping(path ={"/{id}"})
    public TmpTable delete(@PathVariable("id") int id) {
        return tmpTableService.delete(id);
    }

    @GetMapping
    public List<TmpTable> findAll(){
        return tmpTableService.findAll();
    }

}
