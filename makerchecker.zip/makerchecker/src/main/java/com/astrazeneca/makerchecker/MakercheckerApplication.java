package com.astrazeneca.makerchecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakercheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MakercheckerApplication.class, args);
		System.out.println("i am MakercheckerApplication");
	}

}
