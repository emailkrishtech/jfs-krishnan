/**
 * 
 */
package com.astrazeneca.makerchecker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.astrazeneca.makerchecker.entity.TmpTable;
import com.astrazeneca.makerchecker.repository.TmpTableRepository;

/**
 * @author : Krishnan.N
 * @date : Mar 14, 2019
 */
@Service
public class TmpTableServiceImpl implements TmpTableService {
	@Autowired
	private TmpTableRepository repository;
	
	@Override
    public TmpTable create(TmpTable tmpTable) {
        return repository.save(tmpTable);
    }

    @Override
    public TmpTable delete(int id) {
        TmpTable tmpTable = findById(id);
        if(tmpTable != null){
            repository.delete(tmpTable);
        }
        return tmpTable;
    }

    @Override
    public List<TmpTable> findAll() {
        return repository.findAll();
    }

    @Override
    public TmpTable findById(int id) {
        return repository.findOne(id);
    }

    @Override
    public TmpTable update(TmpTable tmpTable) {
        return repository.save(tmpTable);
    }
}
