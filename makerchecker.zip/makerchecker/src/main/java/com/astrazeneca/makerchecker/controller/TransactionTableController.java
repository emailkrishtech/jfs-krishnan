/**
 * 
 */
package com.astrazeneca.makerchecker.controller;

/**
 * @author : Krishnan.N
 * @date : Mar 15, 2019
 */
/**
 * 
 */

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.astrazeneca.makerchecker.entity.TransactionTable;
import com.astrazeneca.makerchecker.service.TransactionTableService;
/**
 * @author : Krishnan.N
 * @date : Mar 15, 2019
 */
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/checker")
public class TransactionTableController {
	@Autowired
	private TransactionTableService transactionTableService;
	
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public TransactionTable create(@RequestBody TransactionTable transactionTable){
         return transactionTableService.create(transactionTable);
    }

    @GetMapping(path = {"/{id}"})
    public TransactionTable findOne(@PathVariable("id") int id){
        return transactionTableService.findById(id);
    }

    @PutMapping(path = {"/{id}"})
    public TransactionTable update(@PathVariable("id") int id, @RequestBody TransactionTable transactionTable){
        
        transactionTable.setCustomerId(id);
        return transactionTableService.update(transactionTable);
    }

    @DeleteMapping(path ={"/{id}"})
    public TransactionTable delete(@PathVariable("id") int id) {
        return transactionTableService.delete(id);
    }

    @GetMapping
    public List<TransactionTable> findAll(){
        return transactionTableService.findAll();
    }

}
