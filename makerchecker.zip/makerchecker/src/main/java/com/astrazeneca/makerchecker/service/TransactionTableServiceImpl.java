/**
 * 
 */
package com.astrazeneca.makerchecker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.astrazeneca.makerchecker.entity.TransactionTable;
import com.astrazeneca.makerchecker.repository.TransactionTableRepository;

/**
 * @author : Krishnan.N
 * @date : Mar 15, 2019
 */
@Service
public class TransactionTableServiceImpl implements  TransactionTableService{
	
	@Autowired
	private TransactionTableRepository repository;
	
	@Override
    public TransactionTable create(TransactionTable transactionTable) {
        return repository.save(transactionTable);
    }

    @Override
    public TransactionTable delete(int id) {
        TransactionTable transactionTable = findById(id);
        if(transactionTable != null){
            repository.delete(transactionTable);
        }
        return transactionTable;
    }

    @Override
    public List<TransactionTable> findAll() {
        return repository.findAll();
    }

    @Override
    public TransactionTable findById(int id) {
        return repository.findOne(id);
    }

    @Override
    public TransactionTable update(TransactionTable transactionTable) {
        return repository.save(transactionTable);
    }
}
