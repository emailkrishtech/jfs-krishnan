/**
 * 
 */
package com.astrazeneca.makerchecker.repository;

import java.util.List;

import org.springframework.data.repository.Repository;


import com.astrazeneca.makerchecker.entity.TransactionTable;
/**
 * @author : Krishnan.N
 * @date : Mar 14, 2019
 */
public interface TransactionTableRepository extends Repository<TransactionTable, Integer> {
	void delete(TransactionTable transactionTable);

    List<TransactionTable> findAll();

    TransactionTable findOne(int id);

    TransactionTable save(TransactionTable transactionTable);
}
